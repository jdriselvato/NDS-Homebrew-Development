This page teaches how to compile our custom ARM7 binary in order to make the Nifi available.

[TOC]

___to be completed___