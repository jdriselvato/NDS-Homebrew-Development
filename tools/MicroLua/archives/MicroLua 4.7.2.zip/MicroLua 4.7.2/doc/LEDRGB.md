This page describes the geeker's reprise of Lua Editor, call LED RGB.

[TOC]


LED RGB (Lua Editor Ds, Recoded, Grabbed and Blooming) is a text-editor, with some features, like addons, or a simple syntax highlighting .
Here is the list of the features:
 
 * Autocompletion updated
 * Run code from RAM (without save)
 * Progress-bar on save
 * Some bugs corrected
 * Graphical amelioration
 * Use LWidget v0.3
 * More options
 * Can run from anywhere in the fat:/ (no absolute path)
 * Showing FPS
 * Addons support

And The list of Addons:

 * [version][]: a very simple addon that display the version of LED on files browser.
 * [programs][] (beta): an addon that include many programs, like a script updater.

If you want to download it, please go on [geeker's website][] or on [microlua's forum post][] and get the latest version (actualy 1.2). You can also click [here][] to download.
Warning: you need [LWidget v0.3][] (or later) to run it !
[geeker's website]: https://sites.google.com/site/geekerprojectscom/home/led-rgb
[microlua's forum post]: http://microlua.xooit.fr/t1090-LED-RGB-reprise.htm
[here]: http://bit.ly/18GwtkR
[programs]: http://bit.ly/1290JCf
[version]: https://sites.google.com/site/geekerprojectscom/home/led-rgb/version?attredirects=0&d=1
[LWidget v0.3]: http://bit.ly/11bkBhB
