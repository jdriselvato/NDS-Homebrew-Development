Learn how you can contribute to the MicroLua project!

[TOC]


Users and gamers
================

Spread the word and download homebrews!

Microlua cannot live without its community using and playing Lua scripts on the console. Even if you don't know how to program with µLua, you are still contributing to it by telling to the world how amazing MicroLua is.

Moreover, your reports are very useful to us for improving MicroLua. I advised you to make reports on the [Issues page](https://sourceforge.net/p/microlua/tickets/).

You can also help us translating some stuff either from French to English or the opposite.


Homebrew developers
===================

Just as above, simple making the community live by creating homebrew is such a great way to contribute!

As developers, you may also have a good point of view on what's wrong with the API of MicroLua so your reports are even more useful.

Finally, if you feel like a teacher you can write tutorials and other documentation so plenty of people can begin to code with MicroLua.


MicroLua developers
===================

Well, I guess you already know what to do there.