This page will help you using Papymouge's MicroFileServer to transfer scripts between computer and NDS.

[TOC]


___to be completed___