
Lorsque vous créez le dossier /moonmemo la racine de votre carte flash, le Bloc-notes est activée.
Dès lors, dans le navigateur de fichiers, il est possible d'ouvrir le Bloc-notes de deux façons.

1/ Tout en pressant R ou L, touchez l'écran tactile.
2/ En pressant le bouton START puis en sélectionnant [Ouvrir le Bloc-notes] dans le menu.

Pour en savoir plus, veuillez-vouz référer à la documentation au chapitre "Utilisation du Bloc-notes".

